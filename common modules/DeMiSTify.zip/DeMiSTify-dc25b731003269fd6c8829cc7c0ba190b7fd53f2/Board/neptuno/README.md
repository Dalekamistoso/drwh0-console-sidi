# NeptUNO board (QMTECH EP4CE55)

Website:  https://github.com/neptuno-fpga/Main_nepUNO/wiki   

Github:    https://github.com/neptuno-fpga

Family:  Cyclone IV E

Device: EP4CE55F23C8

Total logic (LE): 55,856

Total memory (BRAM): 299.5 kB  (2,396,160 bits)  

Embedded Multiplier 9-bit elements: 308             

Total PLLs: 4

