#ifndef _PCECD_H_
#define _PCECD_H_

void pcecd_poll();

#endif