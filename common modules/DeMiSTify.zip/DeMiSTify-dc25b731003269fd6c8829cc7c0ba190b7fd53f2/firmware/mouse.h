#ifndef MOUSE_H

void HandlePS2Mouse(int reset);

#endif

