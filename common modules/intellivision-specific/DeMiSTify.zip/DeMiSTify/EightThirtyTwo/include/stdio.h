#ifndef STDIO_H
#define STDIO_H

#include <printf.h>

#endif

