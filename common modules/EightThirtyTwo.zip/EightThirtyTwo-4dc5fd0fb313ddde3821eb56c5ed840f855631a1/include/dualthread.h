#ifndef DUALTHREAD_H

int thread_asleep();
void thread_sleep();
void thread_wake();

#endif

