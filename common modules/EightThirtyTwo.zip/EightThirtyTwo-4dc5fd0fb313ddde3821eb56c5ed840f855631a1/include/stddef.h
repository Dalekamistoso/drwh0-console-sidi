#ifndef _STDDEF_H
#define _STDDEF_H

typedef unsigned int size_t;
typedef int ssize_t;
typedef int off_t;

#define NULL 0

#endif

